# 🎂 SweetCakes — Tienda Online de Tartas

> Plataforma de ecommerce full-stack para pastelería artesanal. Backend REST con Node.js/Express + MySQL. Frontend estático HTML/CSS/JS puro.

---

## 🚀 Inicio rápido

### Requisitos previos
- **Node.js** ≥ 18 ([descargar](https://nodejs.org))
- **MySQL** 8+ ([MySQL Community](https://dev.mysql.com/downloads/mysql/) o XAMPP/WAMP)
- **MySQL Workbench** (opcional, para gestión visual)

---

## 📁 Estructura del proyecto

```
sweetcakes/
├── backend/              ← API REST Node.js + Express
│   ├── src/
│   │   ├── config/db.js         ← Pool de conexiones MySQL
│   │   ├── middleware/          ← JWT, admin, multer
│   │   ├── routes/              ← Definición de rutas API
│   │   ├── controllers/         ← Handlers HTTP
│   │   ├── services/            ← Lógica de negocio
│   │   └── app.js               ← Express + middlewares globales
│   ├── uploads/                 ← Imágenes subidas por admin
│   ├── server.js                ← Punto de entrada
│   ├── package.json
│   └── .env.example
├── frontend/             ← HTML5 + CSS3 + Vanilla JS
│   ├── css/
│   │   ├── main.css             ← Design system + variables
│   │   └── pages.css            ← Estilos por página
│   ├── js/
│   │   ├── api.js               ← Cliente fetch centralizado
│   │   ├── auth.js              ← JWT + sesión + toasts
│   │   ├── productos.js         ← Catálogo + filtros
│   │   ├── cart.js              ← Carrito + checkout
│   │   ├── pedidos.js           ← Historial de pedidos
│   │   └── admin.js             ← Panel administración
│   ├── admin/
│   │   └── index.html           ← Panel admin (SPA)
│   ├── index.html               ← Home
│   ├── catalogo.html            ← Catálogo con filtros
│   ├── carrito.html             ← Carrito + checkout
│   ├── login.html               ← Login / Registro
│   └── perfil.html              ← Perfil + historial
└── database/
    └── schema.sql               ← Tablas + datos de prueba
```

---

## ⚙️ Configuración paso a paso

### 1. Base de datos MySQL

```bash
# Opción A: desde MySQL CLI
mysql -u root -p < database/schema.sql

# Opción B: desde MySQL Workbench
# File → Open SQL Script → database/schema.sql → Execute (⚡)
```

Esto creará la base de datos `sweetcakes_db` con todas las tablas, relaciones y datos de prueba.

### 2. Backend

```bash
cd backend

# Copiar variables de entorno
copy .env.example .env    # Windows
cp .env.example .env      # Linux/Mac

# Editar .env con tus datos de MySQL
notepad .env   # Windows
nano .env      # Linux/Mac
```

**Variables importantes en `.env`:**
```env
DB_HOST=localhost
DB_PORT=3306
DB_NAME=sweetcakes_db
DB_USER=root
DB_PASSWORD=TU_PASSWORD_MYSQL

JWT_SECRET=una_cadena_aleatoria_larga_y_segura
FRONTEND_URL=http://localhost:5500
```

```bash
# Instalar dependencias
npm install

# Modo desarrollo (con auto-reload)
npm run dev

# Modo producción
npm start
```

La API estará disponible en: **http://localhost:3000/api**

Verificar: `GET http://localhost:3000/api/health`

### 3. Frontend

El frontend es HTML estático — no necesita build. Solo ábrelo con un servidor local:

**Opción A — VS Code Live Server (recomendado):**
1. Instala la extensión "Live Server" en VS Code
2. Abre `sweetcakes/frontend/`
3. Click derecho en `index.html` → "Open with Live Server"
4. Se abrirá en `http://localhost:5500`

**Opción B — Python:**
```bash
cd frontend
python -m http.server 5500
```

**Opción C — npx serve:**
```bash
cd frontend
npx serve -p 5500
```

> ⚠️ **Importante:** Asegúrate de que `FRONTEND_URL=http://localhost:5500` en el `.env` del backend coincide con el puerto donde sirves el frontend.

---

## 👤 Cuentas de prueba

| Rol | Email | Contraseña |
|-----|-------|-----------|
| Admin | admin@sweetcakes.com | password |
| Usuario | maria@ejemplo.com | password |

---

## 🌐 API Endpoints

| Método | Ruta | Auth | Descripción |
|--------|------|------|-------------|
| `POST` | `/api/auth/registro` | ❌ | Registrar usuario |
| `POST` | `/api/auth/login` | ❌ | Login → JWT |
| `GET` | `/api/auth/perfil` | ✅ | Mi perfil |
| `PUT` | `/api/auth/perfil` | ✅ | Actualizar perfil |
| `GET` | `/api/productos` | ❌ | Listar (filtros, búsqueda, paginación) |
| `GET` | `/api/productos/:id` | ❌ | Detalle producto |
| `GET` | `/api/productos/categorias` | ❌ | Listar categorías |
| `POST` | `/api/productos` | 🔑 Admin | Crear producto |
| `PUT` | `/api/productos/:id` | 🔑 Admin | Actualizar producto |
| `DELETE` | `/api/productos/:id` | 🔑 Admin | Eliminar producto |
| `GET` | `/api/carrito` | ✅ | Ver mi carrito |
| `POST` | `/api/carrito` | ✅ | Añadir al carrito |
| `PUT` | `/api/carrito/:id` | ✅ | Actualizar cantidad |
| `DELETE` | `/api/carrito/:id` | ✅ | Eliminar item |
| `DELETE` | `/api/carrito` | ✅ | Vaciar carrito |
| `POST` | `/api/pedidos` | ✅ | Crear pedido |
| `GET` | `/api/pedidos/mis` | ✅ | Mis pedidos |
| `GET` | `/api/pedidos/:id` | ✅ | Detalle pedido |
| `GET` | `/api/admin/estadisticas` | 🔑 Admin | Dashboard stats |
| `GET` | `/api/admin/pedidos` | 🔑 Admin | Todos los pedidos |
| `PUT` | `/api/admin/pedidos/:id/estado` | 🔑 Admin | Cambiar estado |
| `GET` | `/api/admin/usuarios` | 🔑 Admin | Ver usuarios |

---

## 🚀 Despliegue en producción

### Backend → Railway / Render

1. Sube el repositorio a GitHub
2. En Railway/Render conecta el repo y apunta a la carpeta `/backend`
3. Configura las variables de entorno (las mismas del `.env`)
4. Para MySQL usa **PlanetScale** (gratis) o **Railway MySQL**

### Frontend → Netlify / GitHub Pages

1. Arrastra la carpeta `/frontend` a [netlify.com/drop](https://netlify.com/drop)
2. O conecta el repo en Netlify con publish directory = `frontend`
3. Actualiza `API_BASE` en `js/api.js` con la URL de tu backend desplegado

```js
// js/api.js — cambiar en producción:
const API_BASE = 'https://tu-backend.railway.app/api';
```

---

## 🔧 Scripts disponibles

```bash
# Desarrollo backend con auto-reload
npm run dev

# Producción
npm start
```

---

## 🗄️ Diagrama de base de datos

```
usuarios ──┐
           ├──< pedidos ──< detalle_pedidos >── productos
           └──< carrito >── productos
                              │
                         categorias
```

---

## 🧩 Tecnologías

| Capa | Stack |
|------|-------|
| Frontend | HTML5, CSS3 (variables, grid, flexbox), Vanilla JS |
| Backend | Node.js 18+, Express 4, mysql2, bcryptjs, jsonwebtoken, multer |
| Base de datos | MySQL 8 |
| Auth | JWT (Bearer token) |
| Subida imágenes | Multer (local) |
| Fuentes | Google Fonts: Playfair Display + Inter |

---

## 📝 Licencia

MIT — Libre para uso personal y comercial.

---

Hecho con 🍰 y mucho amor por SweetCakes.
