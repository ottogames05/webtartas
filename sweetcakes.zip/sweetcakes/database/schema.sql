-- ============================================================
-- SweetCakes - Script de Base de Datos MySQL
-- Ejecutar en MySQL Workbench o CLI: mysql -u root -p < schema.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS sweetcakes_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE sweetcakes_db;

-- -------------------------------------------------------
-- Tabla: usuarios
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  nombre        VARCHAR(100)  NOT NULL,
  email         VARCHAR(150)  NOT NULL UNIQUE,
  password_hash VARCHAR(255)  NOT NULL,
  rol           ENUM('usuario','admin') NOT NULL DEFAULT 'usuario',
  telefono      VARCHAR(20),
  direccion     TEXT,
  creado_en     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  actualizado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- -------------------------------------------------------
-- Tabla: categorias
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS categorias (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  nombre      VARCHAR(100) NOT NULL,
  descripcion TEXT,
  creado_en   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- -------------------------------------------------------
-- Tabla: productos
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS productos (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  nombre       VARCHAR(150)  NOT NULL,
  descripcion  TEXT,
  precio       DECIMAL(10,2) NOT NULL,
  imagen_url   VARCHAR(255)  DEFAULT '/images/default-cake.jpg',
  stock        INT           NOT NULL DEFAULT 0,
  categoria_id INT,
  activo       BOOLEAN       NOT NULL DEFAULT TRUE,
  destacado    BOOLEAN       NOT NULL DEFAULT FALSE,
  creado_en    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  actualizado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_producto_categoria
    FOREIGN KEY (categoria_id) REFERENCES categorias(id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- -------------------------------------------------------
-- Tabla: carrito
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS carrito (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id  INT NOT NULL,
  producto_id INT NOT NULL,
  cantidad    INT NOT NULL DEFAULT 1,
  agregado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_carrito_usuario
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_carrito_producto
    FOREIGN KEY (producto_id) REFERENCES productos(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  UNIQUE KEY uq_carrito_user_prod (usuario_id, producto_id)
) ENGINE=InnoDB;

-- -------------------------------------------------------
-- Tabla: pedidos
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS pedidos (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id      INT NOT NULL,
  fecha           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  total           DECIMAL(10,2) NOT NULL,
  estado          ENUM('pendiente','procesando','enviado','entregado','cancelado')
                  NOT NULL DEFAULT 'pendiente',
  direccion_envio TEXT,
  notas           TEXT,
  metodo_pago     VARCHAR(50) DEFAULT 'tarjeta',
  creado_en       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  actualizado_en  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_pedido_usuario
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- -------------------------------------------------------
-- Tabla: detalle_pedidos
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS detalle_pedidos (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  pedido_id       INT NOT NULL,
  producto_id     INT,
  nombre_producto VARCHAR(150) NOT NULL,
  cantidad        INT           NOT NULL,
  precio_unitario DECIMAL(10,2) NOT NULL,
  subtotal        DECIMAL(10,2) GENERATED ALWAYS AS (cantidad * precio_unitario) STORED,
  CONSTRAINT fk_detalle_pedido
    FOREIGN KEY (pedido_id) REFERENCES pedidos(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_detalle_producto
    FOREIGN KEY (producto_id) REFERENCES productos(id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- DATOS DE PRUEBA (SEED)
-- ============================================================

-- Categorías
INSERT INTO categorias (nombre, descripcion) VALUES
  ('Tartas Clásicas',    'Las tartas de siempre, con recetas tradicionales'),
  ('Tartas Especiales',  'Creaciones únicas y ediciones limitadas'),
  ('Sin Gluten',         'Tartas aptas para celiacos, sin gluten certificado'),
  ('Veganas',            '100% ingredientes de origen vegetal'),
  ('Tartas de Boda',     'Diseños elegantes para el gran día'),
  ('Cumpleaños',         'Personalizadas para tu celebración');

-- Admin (password: Admin1234!)
INSERT INTO usuarios (nombre, email, password_hash, rol) VALUES
  ('Admin SweetCakes', 'admin@sweetcakes.com',
   '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Usuario de prueba (password: Test1234!)
INSERT INTO usuarios (nombre, email, password_hash, rol, telefono, direccion) VALUES
  ('María García', 'maria@ejemplo.com',
   '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'usuario',
   '612345678', 'Calle Mayor 15, Madrid');

-- Productos
INSERT INTO productos (nombre, descripcion, precio, imagen_url, stock, categoria_id, activo, destacado) VALUES
  ('Tarta de Fresas',
   'Bizcocho esponjoso con nata montada y fresas frescas de temporada. Una delicia ligera y refrescante.',
   28.50, '/uploads/tarta-fresas.jpg', 15, 1, TRUE, TRUE),

  ('Tarta de Chocolate Belga',
   'Intenso chocolate belga 70% cacao con ganache y virutas de chocolate. Para los amantes del chocolate.',
   32.00, '/uploads/tarta-chocolate.jpg', 10, 1, TRUE, TRUE),

  ('Cheesecake New York',
   'Cremoso cheesecake estilo Nueva York sobre base de galleta crujiente, con coulis de frutos rojos.',
   29.90, '/uploads/cheesecake.jpg', 12, 1, TRUE, TRUE),

  ('Tarta Red Velvet',
   'Suave bizcocho rojo con frosting de queso crema. Un clásico americano irresistible.',
   31.00, '/uploads/red-velvet.jpg', 8, 1, TRUE, FALSE),

  ('Tarta de Limón y Merengue',
   'Base crujiente, crema de limón ácida y suave merengue tostado. Equilibrio perfecto de sabores.',
   27.50, '/uploads/tarta-limon.jpg', 20, 1, TRUE, FALSE),

  ('Naked Cake de Vainilla',
   'Elegante tarta desnuda con capas de bizcocho de vainilla, crema de mantequilla y frutos silvestres.',
   45.00, '/uploads/naked-cake.jpg', 5, 2, TRUE, TRUE),

  ('Drip Cake de Caramelo',
   'Espectacular tarta con drippin de caramelo dorado, decorada con macarons y flores comestibles.',
   52.00, '/uploads/drip-cake.jpg', 4, 2, TRUE, TRUE),

  ('Tarta Sin Gluten de Zanahoria',
   'Húmedo bizcocho de zanahoria con nueces y frosting de queso, 100% libre de gluten certificado.',
   34.00, '/uploads/tarta-zanahoria.jpg', 10, 3, TRUE, FALSE),

  ('Cheesecake Sin Gluten',
   'Cheesecake cremoso sobre base de galletas sin gluten. Igual de delicioso, apto para celiacos.',
   32.50, '/uploads/cheesecake-sg.jpg', 8, 3, TRUE, FALSE),

  ('Tarta Vegana de Chocolate',
   'Bizcocho de chocolate con aquafaba, leche de almendras y ganache vegano. Sin ingredientes animales.',
   33.00, '/uploads/tarta-vegana.jpg', 10, 4, TRUE, FALSE),

  ('Tarta Nupcial 3 Pisos',
   'Elegante tarta de boda de 3 pisos con fondant blanco, flores de azúcar y personalización incluida.',
   180.00, '/uploads/tarta-boda.jpg', 3, 5, TRUE, TRUE),

  ('Tarta Personalizada Cumpleaños',
   'Diseño completamente personalizado para tu cumpleaños. Elige sabor, decoración y dedicatoria.',
   38.00, '/uploads/tarta-cumple.jpg', 20, 6, TRUE, FALSE),

  ('Tarta de Tres Leches',
   'Bizcocho empapado en tres tipos de leche con nata montada y canela. Postre mexicano tradicional.',
   26.50, '/uploads/tres-leches.jpg', 15, 1, TRUE, FALSE),

  ('Tarta Ópera',
   'Clásico pastel francés con capas de bizcocho de almendra, café y ganache de chocolate.',
   36.00, '/uploads/tarta-opera.jpg', 6, 2, TRUE, FALSE),

  ('Tarta Vegana de Limón y Coco',
   'Refrescante combinación de limón y coco sobre base de dátiles y almendras. Raw y vegana.',
   35.00, '/uploads/tarta-limon-coco.jpg', 8, 4, TRUE, FALSE);

-- Pedido de prueba
INSERT INTO pedidos (usuario_id, total, estado, direccion_envio, notas) VALUES
  (2, 60.50, 'entregado', 'Calle Mayor 15, Madrid', 'Sin gluten por favor');

INSERT INTO detalle_pedidos (pedido_id, producto_id, nombre_producto, cantidad, precio_unitario) VALUES
  (1, 1, 'Tarta de Fresas', 1, 28.50),
  (1, 2, 'Tarta de Chocolate Belga', 1, 32.00);

-- Pedido pendiente de prueba
INSERT INTO pedidos (usuario_id, total, estado, direccion_envio) VALUES
  (2, 29.90, 'pendiente', 'Calle Mayor 15, Madrid');

INSERT INTO detalle_pedidos (pedido_id, producto_id, nombre_producto, cantidad, precio_unitario) VALUES
  (2, 3, 'Cheesecake New York', 1, 29.90);

-- ============================================================
-- Vistas útiles para el panel admin
-- ============================================================

CREATE OR REPLACE VIEW vista_pedidos_detalle AS
SELECT
  p.id AS pedido_id,
  p.fecha,
  p.total,
  p.estado,
  p.direccion_envio,
  u.nombre AS cliente_nombre,
  u.email  AS cliente_email,
  p.usuario_id
FROM pedidos p
JOIN usuarios u ON p.usuario_id = u.id;

CREATE OR REPLACE VIEW vista_ventas_por_producto AS
SELECT
  pr.id,
  pr.nombre,
  SUM(dp.cantidad)  AS total_vendido,
  SUM(dp.subtotal)  AS ingresos_totales
FROM detalle_pedidos dp
JOIN productos pr ON dp.producto_id = pr.id
JOIN pedidos pe ON dp.pedido_id = pe.id
WHERE pe.estado != 'cancelado'
GROUP BY pr.id, pr.nombre
ORDER BY ingresos_totales DESC;
