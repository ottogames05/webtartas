// js/auth.js
// Gestión de autenticación en el cliente: JWT, sesión, protección de rutas

const auth = (() => {
  const TOKEN_KEY  = 'sc_token';
  const USER_KEY   = 'sc_user';

  // ── Getters ────────────────────────────────────────────────────────
  const getToken = () => localStorage.getItem(TOKEN_KEY);

  const getUser = () => {
    try { return JSON.parse(localStorage.getItem(USER_KEY)); }
    catch { return null; }
  };

  const isLoggedIn = () => !!getToken();

  const isAdmin = () => {
    const u = getUser();
    return u && u.rol === 'admin';
  };

  // ── Setters ────────────────────────────────────────────────────────
  const guardarSesion = (token, usuario) => {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(USER_KEY, JSON.stringify(usuario));
  };

  const logout = () => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    localStorage.removeItem('sc_cart_count');
  };

  // ── Protección de rutas ────────────────────────────────────────────
  /** Redirige a login si el usuario no está autenticado */
  const requireLogin = () => {
    if (!isLoggedIn()) {
      window.location.href = '/login.html?next=' + encodeURIComponent(window.location.pathname);
      return false;
    }
    return true;
  };

  /** Redirige al home si el usuario no es admin */
  const requireAdmin = () => {
    if (!isLoggedIn() || !isAdmin()) {
      window.location.href = '/index.html';
      return false;
    }
    return true;
  };

  // ── UI helpers ─────────────────────────────────────────────────────
  /** Actualiza los enlaces de la navbar según el estado de sesión */
  const actualizarNavbar = () => {
    const usuario = getUser();
    const loginLink  = document.getElementById('nav-login');
    const logoutLink = document.getElementById('nav-logout');
    const perfilLink = document.getElementById('nav-perfil');
    const adminLink  = document.getElementById('nav-admin');
    const userLabel  = document.getElementById('nav-user-label');

    if (usuario) {
      loginLink  && (loginLink.style.display  = 'none');
      logoutLink && (logoutLink.style.display = 'inline-flex');
      perfilLink && (perfilLink.style.display = 'inline-flex');
      if (userLabel) userLabel.textContent = usuario.nombre.split(' ')[0];
      if (adminLink) adminLink.style.display = usuario.rol === 'admin' ? 'inline-flex' : 'none';
    } else {
      loginLink  && (loginLink.style.display  = 'inline-flex');
      logoutLink && (logoutLink.style.display = 'none');
      perfilLink && (perfilLink.style.display = 'none');
      adminLink  && (adminLink.style.display  = 'none');
    }

    // Botón logout
    if (logoutLink) {
      logoutLink.addEventListener('click', (e) => {
        e.preventDefault();
        logout();
        toast.show('Sesión cerrada correctamente', 'info');
        setTimeout(() => window.location.href = '/index.html', 800);
      });
    }
  };

  return { getToken, getUser, isLoggedIn, isAdmin, guardarSesion, logout,
           requireLogin, requireAdmin, actualizarNavbar };
})();

// ── Toast / Notificaciones ─────────────────────────────────────────────────
const toast = (() => {
  const ICONS = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };

  const show = (message, type = 'info', duration = 4000) => {
    let container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      document.body.appendChild(container);
    }

    const el = document.createElement('div');
    el.className = `toast toast-${type}`;
    el.innerHTML = `<span>${ICONS[type]}</span><span>${message}</span>`;
    container.appendChild(el);

    setTimeout(() => el.remove(), duration);
  };

  return { show };
})();

// ── Utilidades generales ──────────────────────────────────────────────────
const utils = {
  /** Formatea precio en euros */
  formatPrecio: (n) => parseFloat(n).toFixed(2).replace('.', ',') + ' €',

  /** Formatea fecha a formato local español */
  formatFecha: (str) => new Date(str).toLocaleDateString('es-ES', {
    day: '2-digit', month: 'long', year: 'numeric'
  }),

  /** Clase CSS del badge de estado de pedido */
  estadoBadge: (estado) => {
    const map = {
      pendiente:  'status-pendiente',
      procesando: 'status-procesando',
      enviado:    'status-enviado',
      entregado:  'status-entregado',
      cancelado:  'status-cancelado',
    };
    const label = estado.charAt(0).toUpperCase() + estado.slice(1);
    return `<span class="order-status-badge ${map[estado] || ''}">${label}</span>`;
  },

  /** Debounce para búsqueda */
  debounce: (fn, delay = 400) => {
    let t;
    return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), delay); };
  },

  /** Actualiza el contador del carrito en la navbar */
  actualizarContadorCarrito: (n) => {
    const badge = document.getElementById('cart-count');
    if (!badge) return;
    if (n > 0) {
      badge.textContent = n > 99 ? '99+' : n;
      badge.classList.remove('hidden');
    } else {
      badge.classList.add('hidden');
    }
  },

  /** Carga el contador del carrito desde la API */
  cargarContadorCarrito: async () => {
    if (!auth.isLoggedIn()) return;
    try {
      const data = await apiCarrito.obtener();
      utils.actualizarContadorCarrito(data.items?.length || 0);
    } catch {}
  },
};

// ── Navbar scrolled effect + hamburger ───────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Navbar scroll effect
  const navbar = document.querySelector('.navbar');
  if (navbar) {
    window.addEventListener('scroll', () => {
      navbar.classList.toggle('scrolled', window.scrollY > 10);
    });
  }

  // Hamburger menu
  const hamburger = document.getElementById('hamburger');
  const navLinks  = document.getElementById('nav-links');
  if (hamburger && navLinks) {
    hamburger.addEventListener('click', () => {
      navLinks.classList.toggle('open');
    });
  }

  // Marcar enlace activo
  const current = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.navbar__link').forEach(link => {
    if (link.getAttribute('href') === current) link.classList.add('active');
  });

  // Actualizar navbar según sesión
  auth.actualizarNavbar();

  // Cargar contador carrito
  utils.cargarContadorCarrito();
});
