// js/admin.js
// Panel de administración: estadísticas, CRUD productos, gestión pedidos y usuarios

document.addEventListener('DOMContentLoaded', async () => {
  // Proteger acceso
  if (!auth.requireAdmin()) return;

  // ── Navegación del sidebar ───────────────────────────────────────────
  const navItems   = document.querySelectorAll('.admin-nav-item[data-section]');
  const sections   = document.querySelectorAll('.admin-section');

  const mostrarSeccion = (id) => {
    sections.forEach(s  => s.classList.toggle('hidden', s.id !== id));
    navItems.forEach(n => n.classList.toggle('active', n.dataset.section === id));
    if (id === 'section-dashboard')  cargarDashboard();
    if (id === 'section-productos')  cargarProductosAdmin();
    if (id === 'section-pedidos')    cargarPedidosAdmin();
    if (id === 'section-usuarios')   cargarUsuariosAdmin();
  };

  navItems.forEach(item => {
    item.addEventListener('click', () => mostrarSeccion(item.dataset.section));
  });

  // Hamburger para mobile admin
  const hamBtn    = document.getElementById('admin-hamburger');
  const sidebar   = document.querySelector('.admin-sidebar');
  hamBtn?.addEventListener('click', () => sidebar?.classList.toggle('open'));

  // ── DASHBOARD ────────────────────────────────────────────────────────
  const cargarDashboard = async () => {
    try {
      const stats = await apiAdmin.estadisticas();

      setVal('stat-ventas',    utils.formatPrecio(stats.total_ventas));
      setVal('stat-pedidos',   stats.num_pedidos);
      setVal('stat-usuarios',  stats.num_usuarios);
      setVal('stat-productos', stats.num_productos);

      // Top productos
      const topEl = document.getElementById('top-productos');
      if (topEl && stats.topProductos) {
        topEl.innerHTML = stats.topProductos.map((p, i) => `
          <tr>
            <td><span style="font-weight:700;color:var(--color-primary)">#${i+1}</span></td>
            <td style="font-weight:500">${p.nombre}</td>
            <td>${p.vendidos}</td>
            <td style="font-weight:700">${utils.formatPrecio(p.ingresos)}</td>
          </tr>`).join('');
      }

      // Pedidos por estado
      const estadosEl = document.getElementById('estados-pedidos');
      if (estadosEl && stats.estadosPedidos) {
        estadosEl.innerHTML = stats.estadosPedidos.map(e => `
          <div style="display:flex;align-items:center;justify-content:space-between;padding:.5rem 0;border-bottom:1px solid var(--color-border)">
            ${utils.estadoBadge(e.estado)}
            <span style="font-weight:700">${e.total}</span>
          </div>`).join('');
      }
    } catch (err) {
      toast.show('Error al cargar estadísticas: ' + err.message, 'error');
    }
  };

  const setVal = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  };

  // ── PRODUCTOS ADMIN ───────────────────────────────────────────────────
  let editandoId = null;

  const cargarProductosAdmin = async () => {
    const el = document.getElementById('admin-productos-tabla');
    if (!el) return;
    el.innerHTML = '<tr><td colspan="6"><div class="spinner"></div></td></tr>';
    try {
      const { productos } = await apiProductos.listar({ limite: 100 });
      el.innerHTML = productos.map(p => `
        <tr>
          <td>
            <img src="${p.imagen_url || '/images/default-cake.jpg'}" alt="${p.nombre}"
                 style="width:48px;height:40px;object-fit:cover;border-radius:6px"
                 onerror="this.src='/images/default-cake.jpg'">
          </td>
          <td style="font-weight:600">${p.nombre}</td>
          <td style="font-weight:700;color:var(--color-primary)">${utils.formatPrecio(p.precio)}</td>
          <td>${p.stock}</td>
          <td>
            <span class="badge ${p.activo ? 'badge-success' : 'badge-error'}">
              ${p.activo ? 'Activo' : 'Inactivo'}
            </span>
          </td>
          <td>
            <div style="display:flex;gap:.5rem">
              <button class="btn btn-sm btn-secondary" onclick="editarProducto(${p.id})">✏️ Editar</button>
              <button class="btn btn-sm" style="background:hsl(0,72%,92%);color:hsl(0,72%,35%)"
                onclick="eliminarProductoAdmin(${p.id})">🗑️</button>
            </div>
          </td>
        </tr>`).join('');
    } catch (err) {
      el.innerHTML = `<tr><td colspan="6">${err.message}</td></tr>`;
    }
  };

  window.editarProducto = async (id) => {
    editandoId = id;
    const modal = document.getElementById('modal-producto');
    if (!modal) return;
    modal.classList.remove('hidden');

    try {
      const p = await apiProductos.obtener(id);
      document.getElementById('prod-nombre').value      = p.nombre;
      document.getElementById('prod-descripcion').value = p.descripcion || '';
      document.getElementById('prod-precio').value      = p.precio;
      document.getElementById('prod-stock').value       = p.stock;
      document.getElementById('prod-categoria').value   = p.categoria_id || '';
      document.getElementById('prod-destacado').checked = p.destacado;
    } catch (err) {
      toast.show(err.message, 'error');
      cerrarModalProducto();
    }
  };

  window.nuevoProducto = () => {
    editandoId = null;
    const form = document.getElementById('form-producto');
    form && form.reset();
    const modal = document.getElementById('modal-producto');
    modal && modal.classList.remove('hidden');
  };

  window.cerrarModalProducto = () => {
    const modal = document.getElementById('modal-producto');
    modal && modal.classList.add('hidden');
    editandoId = null;
  };

  const formProducto = document.getElementById('form-producto');
  formProducto?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = formProducto.querySelector('[type=submit]');
    btn.disabled = true; btn.textContent = 'Guardando...';

    const fd = new FormData();
    fd.append('nombre',      document.getElementById('prod-nombre').value);
    fd.append('descripcion', document.getElementById('prod-descripcion').value);
    fd.append('precio',      document.getElementById('prod-precio').value);
    fd.append('stock',       document.getElementById('prod-stock').value);
    fd.append('categoria_id',document.getElementById('prod-categoria').value);
    fd.append('destacado',   document.getElementById('prod-destacado').checked);
    const imgFile = document.getElementById('prod-imagen').files[0];
    if (imgFile) fd.append('imagen', imgFile);

    try {
      if (editandoId) {
        await apiProductos.actualizar(editandoId, fd);
        toast.show('Producto actualizado ✅', 'success');
      } else {
        await apiProductos.crear(fd);
        toast.show('Producto creado ✅', 'success');
      }
      cerrarModalProducto();
      await cargarProductosAdmin();
    } catch (err) {
      toast.show(err.message, 'error');
    } finally {
      btn.disabled = false;
      btn.textContent = 'Guardar';
    }
  });

  window.eliminarProductoAdmin = async (id) => {
    if (!confirm('¿Eliminar este producto?')) return;
    try {
      await apiProductos.eliminar(id);
      toast.show('Producto eliminado', 'info');
      await cargarProductosAdmin();
    } catch (err) {
      toast.show(err.message, 'error');
    }
  };

  // ── PEDIDOS ADMIN ─────────────────────────────────────────────────────
  const cargarPedidosAdmin = async () => {
    const el = document.getElementById('admin-pedidos-tabla');
    if (!el) return;
    el.innerHTML = '<tr><td colspan="6"><div class="spinner"></div></td></tr>';
    try {
      const filtroPedido = document.getElementById('filtro-estado-pedido')?.value;
      const pedidos = await apiAdmin.pedidos(filtroPedido || null);
      el.innerHTML = pedidos.map(p => `
        <tr>
          <td style="font-weight:700">#${p.id}</td>
          <td>
            <div style="font-weight:500">${p.cliente_nombre}</div>
            <div class="text-sm text-muted">${p.cliente_email}</div>
          </td>
          <td>${utils.formatFecha(p.fecha)}</td>
          <td style="font-weight:700;color:var(--color-primary)">${utils.formatPrecio(p.total)}</td>
          <td>${utils.estadoBadge(p.estado)}</td>
          <td>
            <select class="form-select" style="font-size:.8rem;padding:.25rem .5rem"
              onchange="cambiarEstadoAdmin(${p.id}, this.value)">
              ${['pendiente','procesando','enviado','entregado','cancelado'].map(s =>
                `<option value="${s}" ${s === p.estado ? 'selected' : ''}>${s}</option>`
              ).join('')}
            </select>
          </td>
        </tr>`).join('');
    } catch (err) {
      el.innerHTML = `<tr><td colspan="6">${err.message}</td></tr>`;
    }
  };

  window.cambiarEstadoAdmin = async (id, estado) => {
    try {
      await apiAdmin.cambiarEstado(id, estado);
      toast.show(`Estado actualizado a "${estado}"`, 'success');
    } catch (err) {
      toast.show(err.message, 'error');
    }
  };

  const filtroPedidoSel = document.getElementById('filtro-estado-pedido');
  filtroPedidoSel?.addEventListener('change', cargarPedidosAdmin);

  // ── USUARIOS ADMIN ────────────────────────────────────────────────────
  const cargarUsuariosAdmin = async () => {
    const el = document.getElementById('admin-usuarios-tabla');
    if (!el) return;
    el.innerHTML = '<tr><td colspan="5"><div class="spinner"></div></td></tr>';
    try {
      const usuarios = await apiAdmin.usuarios();
      el.innerHTML = usuarios.map(u => `
        <tr>
          <td style="font-weight:500">${u.nombre}</td>
          <td>${u.email}</td>
          <td>
            <span class="badge ${u.rol === 'admin' ? 'badge-primary' : 'badge-muted'}">
              ${u.rol}
            </span>
          </td>
          <td>${u.num_pedidos}</td>
          <td>${utils.formatFecha(u.creado_en)}</td>
        </tr>`).join('');
    } catch (err) {
      el.innerHTML = `<tr><td colspan="5">${err.message}</td></tr>`;
    }
  };

  // ── Cargar sección inicial ────────────────────────────────────────────
  // Cargar categorías en el select del modal de producto
  const catSelect = document.getElementById('prod-categoria');
  if (catSelect) {
    try {
      const cats = await apiProductos.categorias();
      catSelect.innerHTML = '<option value="">Sin categoría</option>' +
        cats.map(c => `<option value="${c.id}">${c.nombre}</option>`).join('');
    } catch {}
  }

  mostrarSeccion('section-dashboard');
});
