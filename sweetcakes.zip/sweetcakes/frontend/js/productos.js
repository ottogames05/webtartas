// js/productos.js
// Lógica del catálogo: carga, filtros, búsqueda, paginación

document.addEventListener('DOMContentLoaded', async () => {
  // ── Estado ──────────────────────────────────────────────────────────
  let filtros = { pagina: 1, limite: 12 };
  let totalProductos = 0;

  // ── Referencias DOM ─────────────────────────────────────────────────
  const grid        = document.getElementById('products-grid');
  const countLabel  = document.getElementById('catalog-count');
  const inputBuscar = document.getElementById('input-search');
  const selectSort  = document.getElementById('select-sort');
  const catButtons  = document.querySelectorAll('.category-btn');
  const inputMin    = document.getElementById('price-min');
  const inputMax    = document.getElementById('price-max');
  const btnAplicar  = document.getElementById('btn-apply-price');
  const btnReset    = document.getElementById('btn-reset-filters');
  const pagination  = document.getElementById('pagination');

  if (!grid) return; // No estamos en la página de catálogo

  // ── Carga de productos ───────────────────────────────────────────────
  const cargarProductos = async () => {
    mostrarSkeleton();
    try {
      const params = {};
      if (filtros.categoria)  params.categoria  = filtros.categoria;
      if (filtros.busqueda)   params.busqueda   = filtros.busqueda;
      if (filtros.minPrecio)  params.minPrecio  = filtros.minPrecio;
      if (filtros.maxPrecio)  params.maxPrecio  = filtros.maxPrecio;
      if (filtros.destacado)  params.destacado  = true;
      params.pagina  = filtros.pagina;
      params.limite  = filtros.limite;

      const { productos, total } = await apiProductos.listar(params);
      totalProductos = total;
      renderProductos(productos);
      if (countLabel) countLabel.textContent = `${total} producto${total !== 1 ? 's' : ''} encontrado${total !== 1 ? 's' : ''}`;
      renderPaginacion(total);
    } catch (err) {
      grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1">
        <span class="empty-state__icon">😕</span>
        <h3>Error al cargar productos</h3>
        <p>${err.message}</p>
      </div>`;
    }
  };

  // ── Render tarjetas ──────────────────────────────────────────────────
  const renderProductos = (productos) => {
    if (!productos.length) {
      grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1">
        <span class="empty-state__icon">🔍</span>
        <h3>Sin resultados</h3>
        <p>Prueba con otros filtros o términos de búsqueda.</p>
        <button class="btn btn-secondary mt-6" onclick="resetFiltros()">Limpiar filtros</button>
      </div>`;
      return;
    }

    grid.innerHTML = productos.map(p => `
      <article class="product-card" data-id="${p.id}">
        <div class="product-card__img-wrap">
          <img class="product-card__img"
               src="${p.imagen_url || '/images/default-cake.jpg'}"
               alt="${p.nombre}"
               onerror="this.src='/images/default-cake.jpg'">
          ${p.destacado ? '<span class="badge badge-primary product-card__badge">⭐ Destacado</span>' : ''}
          <button class="product-card__wishlist" title="Añadir a favoritos">♡</button>
        </div>
        <div class="product-card__body">
          <p class="product-card__category">${p.categoria_nombre || 'Pastelería'}</p>
          <h3 class="product-card__name">${p.nombre}</h3>
          <p class="product-card__desc">${p.descripcion || ''}</p>
          <div class="product-card__footer">
            <div>
              <div class="product-card__price">${utils.formatPrecio(p.precio)}</div>
              <div class="product-card__price-unit">por unidad</div>
            </div>
            <button class="product-card__add"
                    id="btn-add-${p.id}"
                    onclick="agregarAlCarrito(${p.id}, this)"
                    ${p.stock === 0 ? 'disabled' : ''}>
              ${p.stock === 0 ? '❌ Sin stock' : '🛒 Añadir'}
            </button>
          </div>
        </div>
      </article>
    `).join('');

    // Click en tarjeta → detalle producto
    grid.querySelectorAll('.product-card').forEach(card => {
      card.addEventListener('click', (e) => {
        if (e.target.closest('button')) return;
        window.location.href = `producto.html?id=${card.dataset.id}`;
      });
      card.style.cursor = 'pointer';
    });
  };

  // ── Skeleton loader ──────────────────────────────────────────────────
  const mostrarSkeleton = () => {
    grid.innerHTML = Array(6).fill(0).map(() => `
      <div class="card" style="overflow:hidden">
        <div class="skeleton" style="height:200px"></div>
        <div style="padding:1rem">
          <div class="skeleton" style="height:12px;width:40%;margin-bottom:.5rem"></div>
          <div class="skeleton" style="height:18px;margin-bottom:.5rem"></div>
          <div class="skeleton" style="height:14px;margin-bottom:1rem"></div>
          <div class="skeleton" style="height:36px;border-radius:99px"></div>
        </div>
      </div>
    `).join('');
  };

  // ── Paginación ───────────────────────────────────────────────────────
  const renderPaginacion = (total) => {
    if (!pagination) return;
    const totalPags = Math.ceil(total / filtros.limite);
    if (totalPags <= 1) { pagination.innerHTML = ''; return; }

    let html = '<div class="flex justify-center gap-2 mt-8">';
    for (let i = 1; i <= totalPags; i++) {
      html += `<button class="btn btn-sm ${i === filtros.pagina ? 'btn-primary' : 'btn-secondary'}"
                        onclick="irAPagina(${i})">${i}</button>`;
    }
    html += '</div>';
    pagination.innerHTML = html;
  };

  // ── Filtros ──────────────────────────────────────────────────────────
  if (inputBuscar) {
    inputBuscar.addEventListener('input', utils.debounce((e) => {
      filtros.busqueda = e.target.value.trim();
      filtros.pagina = 1;
      cargarProductos();
    }, 400));
  }

  if (selectSort) {
    selectSort.addEventListener('change', () => {
      filtros.sort = selectSort.value;
      filtros.pagina = 1;
      cargarProductos();
    });
  }

  catButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      catButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      filtros.categoria = btn.dataset.cat || '';
      filtros.pagina = 1;
      cargarProductos();
    });
  });

  if (btnAplicar) {
    btnAplicar.addEventListener('click', () => {
      filtros.minPrecio = inputMin.value || '';
      filtros.maxPrecio = inputMax.value || '';
      filtros.pagina = 1;
      cargarProductos();
    });
  }

  if (btnReset) {
    btnReset.addEventListener('click', resetFiltros);
  }

  // ── Funciones globales ───────────────────────────────────────────────
  window.resetFiltros = () => {
    filtros = { pagina: 1, limite: 12 };
    if (inputBuscar) inputBuscar.value = '';
    if (inputMin)    inputMin.value    = '';
    if (inputMax)    inputMax.value    = '';
    catButtons.forEach(b => b.classList.remove('active'));
    cargarProductos();
  };

  window.irAPagina = (n) => {
    filtros.pagina = n;
    window.scrollTo({ top: 0, behavior: 'smooth' });
    cargarProductos();
  };

  window.agregarAlCarrito = async (productoId, btn) => {
    if (!auth.isLoggedIn()) {
      toast.show('Inicia sesión para añadir al carrito', 'warning');
      setTimeout(() => window.location.href = '/login.html', 1200);
      return;
    }
    try {
      btn.disabled = true;
      await apiCarrito.agregar(productoId, 1);
      btn.classList.add('added');
      btn.textContent = '✅ Añadido';
      toast.show('¡Tarta añadida al carrito! 🎂', 'success');
      await utils.cargarContadorCarrito();
      setTimeout(() => {
        btn.classList.remove('added');
        btn.innerHTML = '🛒 Añadir';
        btn.disabled = false;
      }, 2000);
    } catch (err) {
      toast.show(err.message || 'Error al añadir al carrito', 'error');
      btn.disabled = false;
    }
  };

  // ── Cargar categorías en el sidebar ─────────────────────────────────
  const catList = document.getElementById('category-list');
  if (catList) {
    try {
      const cats = await apiProductos.categorias();
      catList.innerHTML = `
        <button class="category-btn active" data-cat="" onclick="">
          Todas las tartas <span class="category-count">–</span>
        </button>
        ${cats.map(c => `
          <button class="category-btn" data-cat="${c.id}">
            ${c.nombre} <span class="category-count">${c.id}</span>
          </button>
        `).join('')}
      `;
      catList.querySelectorAll('.category-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          catList.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          filtros.categoria = btn.dataset.cat || '';
          filtros.pagina = 1;
          cargarProductos();
        });
      });
    } catch {}
  }

  // Iniciar carga
  cargarProductos();
});
