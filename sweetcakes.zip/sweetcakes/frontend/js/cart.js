// js/cart.js
// Lógica completa del carrito de compras y checkout

document.addEventListener('DOMContentLoaded', async () => {
  const cartItemsEl   = document.getElementById('cart-items');
  const summaryEl     = document.getElementById('cart-summary');
  const emptyStateEl  = document.getElementById('cart-empty');
  const checkoutForm  = document.getElementById('checkout-form');
  const confirmBtn    = document.getElementById('btn-confirm-order');

  if (!cartItemsEl) return; // No estamos en la página del carrito

  // ── Carga del carrito ────────────────────────────────────────────────
  const cargarCarrito = async () => {
    cartItemsEl.innerHTML = '<div class="spinner"></div>';
    try {
      const { items, subtotal } = await apiCarrito.obtener();
      utils.actualizarContadorCarrito(items.length);

      if (!items.length) {
        cartItemsEl.innerHTML = '';
        emptyStateEl && emptyStateEl.classList.remove('hidden');
        summaryEl    && summaryEl.classList.add('hidden');
        return;
      }

      emptyStateEl && emptyStateEl.classList.add('hidden');
      summaryEl    && summaryEl.classList.remove('hidden');

      renderItems(items);
      renderResumen(subtotal);
    } catch (err) {
      cartItemsEl.innerHTML = `<p class="text-center text-muted">Error: ${err.message}</p>`;
    }
  };

  // ── Render lista de items ────────────────────────────────────────────
  const renderItems = (items) => {
    cartItemsEl.innerHTML = items.map(item => `
      <div class="cart-item" id="cart-item-${item.id}">
        <img class="cart-item__img"
             src="${item.imagen_url || '/images/default-cake.jpg'}"
             alt="${item.nombre}"
             onerror="this.src='/images/default-cake.jpg'">
        <div>
          <div class="cart-item__name">${item.nombre}</div>
          <div class="cart-item__price">${utils.formatPrecio(item.precio)} / ud.</div>
          <div class="quantity-ctrl">
            <button class="qty-btn" onclick="cambiarCantidad(${item.id}, ${item.cantidad - 1})">−</button>
            <span class="qty-val">${item.cantidad}</span>
            <button class="qty-btn" onclick="cambiarCantidad(${item.id}, ${item.cantidad + 1})"
              ${item.cantidad >= item.stock ? 'disabled title="Stock máximo"' : ''}>+</button>
          </div>
          <button class="cart-item__remove" onclick="eliminarItem(${item.id})">
            🗑️ Eliminar
          </button>
        </div>
        <div>
          <div class="cart-item__subtotal">${utils.formatPrecio(item.precio * item.cantidad)}</div>
        </div>
      </div>
    `).join('');
  };

  // ── Render resumen ───────────────────────────────────────────────────
  const renderResumen = (subtotal) => {
    const envio = subtotal >= 30 ? 0 : 3.99;
    const total = subtotal + envio;

    const subtotalEl = document.getElementById('summary-subtotal');
    const envioEl    = document.getElementById('summary-envio');
    const totalEl    = document.getElementById('summary-total');

    if (subtotalEl) subtotalEl.textContent = utils.formatPrecio(subtotal);
    if (envioEl)    envioEl.textContent    = envio === 0 ? 'Gratis 🎉' : utils.formatPrecio(envio);
    if (totalEl)    totalEl.textContent    = utils.formatPrecio(total);

    // Guardar total para el pedido
    window._orderTotal = total;
  };

  // ── Cambiar cantidad ─────────────────────────────────────────────────
  window.cambiarCantidad = async (itemId, nuevaCantidad) => {
    try {
      if (nuevaCantidad <= 0) {
        await eliminarItem(itemId);
        return;
      }
      await apiCarrito.actualizar(itemId, nuevaCantidad);
      await cargarCarrito();
    } catch (err) {
      toast.show(err.message || 'Error al actualizar', 'error');
    }
  };

  // ── Eliminar item ────────────────────────────────────────────────────
  window.eliminarItem = async (itemId) => {
    try {
      const el = document.getElementById(`cart-item-${itemId}`);
      if (el) { el.style.opacity = '0.4'; el.style.pointerEvents = 'none'; }
      await apiCarrito.eliminar(itemId);
      toast.show('Producto eliminado del carrito', 'info');
      await cargarCarrito();
    } catch (err) {
      toast.show(err.message || 'Error al eliminar', 'error');
    }
  };

  // ── Vaciar carrito ───────────────────────────────────────────────────
  const btnVaciar = document.getElementById('btn-clear-cart');
  if (btnVaciar) {
    btnVaciar.addEventListener('click', async () => {
      if (!confirm('¿Vaciar todo el carrito?')) return;
      try {
        await apiCarrito.vaciar();
        toast.show('Carrito vaciado', 'info');
        await cargarCarrito();
      } catch (err) {
        toast.show(err.message, 'error');
      }
    });
  }

  // ── Checkout / Confirmar pedido ──────────────────────────────────────
  if (checkoutForm) {
    checkoutForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!auth.requireLogin()) return;

      confirmBtn.disabled = true;
      confirmBtn.textContent = 'Procesando...';

      const datos = {
        direccion_envio: document.getElementById('checkout-direccion').value,
        notas:           document.getElementById('checkout-notas').value,
        metodo_pago:     document.getElementById('checkout-pago').value,
      };

      try {
        const { pedido } = await apiPedidos.crear(datos);
        toast.show('¡Pedido realizado con éxito! 🎂', 'success');

        // Mostrar confirmación
        const confirmEl = document.getElementById('order-confirmed');
        const orderIdEl = document.getElementById('confirmed-order-id');
        if (confirmEl) {
          if (orderIdEl) orderIdEl.textContent = pedido.id;
          checkoutForm.closest('.checkout-form-section')?.classList.add('hidden');
          confirmEl.classList.remove('hidden');
        } else {
          setTimeout(() => window.location.href = '/perfil.html#pedidos', 1500);
        }

        await cargarCarrito();
      } catch (err) {
        toast.show(err.message || 'Error al procesar el pedido', 'error');
        confirmBtn.disabled = false;
        confirmBtn.textContent = 'Confirmar Pedido';
      }
    });
  }

  // ── Paso a checkout ──────────────────────────────────────────────────
  const btnCheckout = document.getElementById('btn-go-checkout');
  if (btnCheckout) {
    btnCheckout.addEventListener('click', () => {
      if (!auth.isLoggedIn()) {
        toast.show('Inicia sesión para completar tu compra', 'warning');
        setTimeout(() => window.location.href = '/login.html?next=/carrito.html', 1200);
        return;
      }
      // Mostrar formulario checkout
      const checkoutSection = document.getElementById('checkout-section');
      if (checkoutSection) {
        checkoutSection.classList.remove('hidden');
        checkoutSection.scrollIntoView({ behavior: 'smooth' });
        // Pre-llenar dirección del perfil
        apiAuth.perfil().then(u => {
          const dirInput = document.getElementById('checkout-direccion');
          if (dirInput && u.direccion) dirInput.value = u.direccion;
        }).catch(() => {});
      }
    });
  }

  // ── Iniciar ──────────────────────────────────────────────────────────
  if (!auth.isLoggedIn()) {
    emptyStateEl && emptyStateEl.classList.remove('hidden');
    summaryEl    && summaryEl.classList.add('hidden');
    cartItemsEl.innerHTML = '';
    const msg = document.getElementById('login-to-view-cart');
    msg && msg.classList.remove('hidden');
    return;
  }

  await cargarCarrito();
});
