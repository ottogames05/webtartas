// js/api.js
// Cliente API centralizado — todas las llamadas fetch pasan por aquí

const API_BASE = 'http://localhost:3000/api';

/**
 * Wrapper genérico de fetch con manejo de errores y JWT automático.
 * @param {string} endpoint - Ruta relativa, ej: '/productos'
 * @param {object} options  - Opciones fetch adicionales
 * @returns {Promise<any>}
 */
async function apiFetch(endpoint, options = {}) {
  const token = auth.getToken();

  const headers = {
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` }),
    ...(options.headers || {}),
  };

  // Si se envía FormData no forzamos Content-Type (el browser lo pone solo)
  if (options.body instanceof FormData) {
    delete headers['Content-Type'];
  }

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });

  // Token expirado
  if (response.status === 401) {
    auth.logout();
    window.location.href = '/login.html';
    return;
  }

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.error || data.message || `Error ${response.status}`);
  }

  return data;
}

// ── Endpoints de Auth ────────────────────────────────────────────────
const apiAuth = {
  registro: (datos) => apiFetch('/auth/registro', { method: 'POST', body: JSON.stringify(datos) }),
  login:    (datos) => apiFetch('/auth/login',    { method: 'POST', body: JSON.stringify(datos) }),
  perfil:   ()      => apiFetch('/auth/perfil'),
  actualizarPerfil: (datos) => apiFetch('/auth/perfil', { method: 'PUT', body: JSON.stringify(datos) }),
};

// ── Endpoints de Productos ────────────────────────────────────────────
const apiProductos = {
  listar:   (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return apiFetch(`/productos${qs ? '?' + qs : ''}`);
  },
  obtener:  (id) => apiFetch(`/productos/${id}`),
  categorias: ()  => apiFetch('/productos/categorias'),
  crear:    (formData) => apiFetch('/productos', { method: 'POST', body: formData }),
  actualizar: (id, formData) => apiFetch(`/productos/${id}`, { method: 'PUT', body: formData }),
  eliminar: (id) => apiFetch(`/productos/${id}`, { method: 'DELETE' }),
};

// ── Endpoints de Carrito ──────────────────────────────────────────────
const apiCarrito = {
  obtener:   ()                  => apiFetch('/carrito'),
  agregar:   (producto_id, cantidad = 1) =>
    apiFetch('/carrito', { method: 'POST', body: JSON.stringify({ producto_id, cantidad }) }),
  actualizar: (id, cantidad)     =>
    apiFetch(`/carrito/${id}`, { method: 'PUT', body: JSON.stringify({ cantidad }) }),
  eliminar:  (id)                => apiFetch(`/carrito/${id}`, { method: 'DELETE' }),
  vaciar:    ()                  => apiFetch('/carrito', { method: 'DELETE' }),
};

// ── Endpoints de Pedidos ──────────────────────────────────────────────
const apiPedidos = {
  crear:     (datos)  => apiFetch('/pedidos', { method: 'POST', body: JSON.stringify(datos) }),
  misPedidos: ()      => apiFetch('/pedidos/mis'),
  detalle:   (id)     => apiFetch(`/pedidos/${id}`),
};

// ── Endpoints de Admin ────────────────────────────────────────────────
const apiAdmin = {
  estadisticas: ()           => apiFetch('/admin/estadisticas'),
  usuarios:     ()           => apiFetch('/admin/usuarios'),
  cambiarRol:   (id, rol)    =>
    apiFetch(`/admin/usuarios/${id}/rol`, { method: 'PUT', body: JSON.stringify({ rol }) }),
  pedidos:      (estado)     => {
    const qs = estado ? `?estado=${estado}` : '';
    return apiFetch(`/admin/pedidos${qs}`);
  },
  detallePedido: (id)        => apiFetch(`/admin/pedidos/${id}`),
  cambiarEstado: (id, estado) =>
    apiFetch(`/admin/pedidos/${id}/estado`, { method: 'PUT', body: JSON.stringify({ estado }) }),
};
