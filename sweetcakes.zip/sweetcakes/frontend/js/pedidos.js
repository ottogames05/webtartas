// js/pedidos.js
// Historial de pedidos y detalle en el perfil de usuario

document.addEventListener('DOMContentLoaded', async () => {
  const listEl   = document.getElementById('orders-list');
  const detailEl = document.getElementById('order-detail');

  if (!listEl) return;

  if (!auth.requireLogin()) return;

  const cargarPedidos = async () => {
    listEl.innerHTML = '<div class="spinner"></div>';
    try {
      const pedidos = await apiPedidos.misPedidos();

      if (!pedidos.length) {
        listEl.innerHTML = `
          <div class="empty-state">
            <span class="empty-state__icon">📦</span>
            <h3>Sin pedidos todavía</h3>
            <p>¡Explora nuestro catálogo y haz tu primer pedido!</p>
            <a href="catalogo.html" class="btn btn-primary mt-6">Ver tartas</a>
          </div>`;
        return;
      }

      listEl.innerHTML = pedidos.map(p => `
        <div class="card" style="padding:var(--space-5);margin-bottom:var(--space-4);cursor:pointer"
             onclick="verDetalle(${p.id})">
          <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem">
            <div>
              <div style="font-weight:700;font-family:var(--font-heading)">Pedido #${p.id}</div>
              <div class="text-muted text-sm">${utils.formatFecha(p.fecha)}</div>
            </div>
            ${utils.estadoBadge(p.estado)}
          </div>
          <div style="display:flex;justify-content:space-between;margin-top:var(--space-3);font-size:.9rem">
            <span class="text-muted">${p.num_productos} producto${p.num_productos !== 1 ? 's' : ''}</span>
            <span style="font-weight:700;color:var(--color-primary)">${utils.formatPrecio(p.total)}</span>
          </div>
        </div>
      `).join('');
    } catch (err) {
      listEl.innerHTML = `<p class="text-muted">Error: ${err.message}</p>`;
    }
  };

  window.verDetalle = async (pedidoId) => {
    if (!detailEl) return;
    detailEl.innerHTML = '<div class="spinner"></div>';
    detailEl.classList.remove('hidden');

    try {
      const pedido = await apiPedidos.detalle(pedidoId);

      detailEl.innerHTML = `
        <div class="card" style="padding:var(--space-6)">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--space-5)">
            <h3>Pedido #${pedido.id}</h3>
            ${utils.estadoBadge(pedido.estado)}
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:var(--space-4);margin-bottom:var(--space-5)">
            <div>
              <div class="text-muted text-sm" style="margin-bottom:.25rem">Fecha</div>
              <div style="font-weight:500">${utils.formatFecha(pedido.fecha)}</div>
            </div>
            <div>
              <div class="text-muted text-sm" style="margin-bottom:.25rem">Método de pago</div>
              <div style="font-weight:500;text-transform:capitalize">${pedido.metodo_pago || 'Tarjeta'}</div>
            </div>
            <div style="grid-column:1/-1">
              <div class="text-muted text-sm" style="margin-bottom:.25rem">Dirección de envío</div>
              <div style="font-weight:500">${pedido.direccion_envio || '—'}</div>
            </div>
            ${pedido.notas ? `<div style="grid-column:1/-1">
              <div class="text-muted text-sm" style="margin-bottom:.25rem">Notas</div>
              <div style="font-weight:500">${pedido.notas}</div>
            </div>` : ''}
          </div>
          <table class="data-table" style="margin-bottom:var(--space-5)">
            <thead>
              <tr><th>Producto</th><th>Cant.</th><th>Precio/ud.</th><th>Subtotal</th></tr>
            </thead>
            <tbody>
              ${pedido.detalles.map(d => `
                <tr>
                  <td style="font-weight:500">${d.nombre_producto}</td>
                  <td>${d.cantidad}</td>
                  <td>${utils.formatPrecio(d.precio_unitario)}</td>
                  <td style="font-weight:700;color:var(--color-primary)">${utils.formatPrecio(d.precio_unitario * d.cantidad)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <div style="text-align:right">
            <div class="text-muted text-sm">Total pedido</div>
            <div style="font-family:var(--font-heading);font-size:1.75rem;font-weight:700;color:var(--color-primary)">
              ${utils.formatPrecio(pedido.total)}
            </div>
          </div>
          <div style="margin-top:var(--space-5);text-align:right">
            <button class="btn btn-ghost btn-sm" onclick="cerrarDetalle()">✕ Cerrar</button>
          </div>
        </div>`;
    } catch (err) {
      detailEl.innerHTML = `<p class="text-muted">Error: ${err.message}</p>`;
    }
  };

  window.cerrarDetalle = () => {
    if (detailEl) detailEl.innerHTML = '';
  };

  await cargarPedidos();
});
