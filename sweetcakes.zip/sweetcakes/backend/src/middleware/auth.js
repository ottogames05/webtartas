// src/middleware/auth.js
// Middleware para verificar tokens JWT en rutas protegidas
const jwt = require('jsonwebtoken');

/**
 * Verifica que la request incluya un JWT válido en el header Authorization.
 * Si es válido, inyecta el payload en req.usuario.
 */
const verificarToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token de autenticación requerido' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.usuario = payload; // { id, email, rol, nombre }
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Sesión expirada, por favor inicia sesión de nuevo' });
    }
    return res.status(401).json({ error: 'Token inválido' });
  }
};

module.exports = { verificarToken };
