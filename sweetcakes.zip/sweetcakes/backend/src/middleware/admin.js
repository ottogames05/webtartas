// src/middleware/admin.js
// Middleware que restringe el acceso solo a usuarios con rol 'admin'
// Debe usarse DESPUÉS de verificarToken

const soloAdmin = (req, res, next) => {
  if (!req.usuario || req.usuario.rol !== 'admin') {
    return res.status(403).json({ error: 'Acceso denegado. Se requieren permisos de administrador.' });
  }
  next();
};

module.exports = { soloAdmin };
