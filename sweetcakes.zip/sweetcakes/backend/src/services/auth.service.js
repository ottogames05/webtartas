// src/services/auth.service.js
// Lógica de negocio para autenticación
const bcrypt = require('bcryptjs');
const jwt    = require('jsonwebtoken');
const db     = require('../config/db');

/**
 * Registra un nuevo usuario en la base de datos.
 * @param {string} nombre
 * @param {string} email
 * @param {string} password - Contraseña en texto plano
 * @returns {object} Usuario creado (sin password)
 */
const registrarUsuario = async (nombre, email, password) => {
  // Verificar si el email ya existe
  const [existentes] = await db.query(
    'SELECT id FROM usuarios WHERE email = ?', [email]
  );
  if (existentes.length > 0) {
    throw { status: 409, message: 'El email ya está registrado' };
  }

  // Encriptar contraseña
  const salt         = await bcrypt.genSalt(10);
  const passwordHash = await bcrypt.hash(password, salt);

  // Insertar usuario
  const [result] = await db.query(
    'INSERT INTO usuarios (nombre, email, password_hash) VALUES (?, ?, ?)',
    [nombre, email, passwordHash]
  );

  return { id: result.insertId, nombre, email, rol: 'usuario' };
};

/**
 * Autentica un usuario y devuelve un JWT.
 * @param {string} email
 * @param {string} password
 * @returns {{ token: string, usuario: object }}
 */
const loginUsuario = async (email, password) => {
  // Buscar usuario
  const [rows] = await db.query(
    'SELECT id, nombre, email, password_hash, rol FROM usuarios WHERE email = ?',
    [email]
  );
  if (rows.length === 0) {
    throw { status: 401, message: 'Credenciales incorrectas' };
  }

  const usuario = rows[0];

  // Verificar contraseña
  const coincide = await bcrypt.compare(password, usuario.password_hash);
  if (!coincide) {
    throw { status: 401, message: 'Credenciales incorrectas' };
  }

  // Generar JWT
  const payload = { id: usuario.id, nombre: usuario.nombre, email: usuario.email, rol: usuario.rol };
  const token   = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });

  return {
    token,
    usuario: { id: usuario.id, nombre: usuario.nombre, email: usuario.email, rol: usuario.rol },
  };
};

/**
 * Obtiene el perfil completo de un usuario por ID.
 */
const obtenerPerfil = async (usuarioId) => {
  const [rows] = await db.query(
    'SELECT id, nombre, email, rol, telefono, direccion, creado_en FROM usuarios WHERE id = ?',
    [usuarioId]
  );
  if (rows.length === 0) throw { status: 404, message: 'Usuario no encontrado' };
  return rows[0];
};

/**
 * Actualiza los datos del perfil del usuario.
 */
const actualizarPerfil = async (usuarioId, datos) => {
  const { nombre, telefono, direccion } = datos;
  await db.query(
    'UPDATE usuarios SET nombre = ?, telefono = ?, direccion = ? WHERE id = ?',
    [nombre, telefono, direccion, usuarioId]
  );
  return obtenerPerfil(usuarioId);
};

module.exports = { registrarUsuario, loginUsuario, obtenerPerfil, actualizarPerfil };
