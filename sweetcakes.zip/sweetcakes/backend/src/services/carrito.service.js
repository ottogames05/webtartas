// src/services/carrito.service.js
// Lógica de negocio para el carrito de compras
const db = require('../config/db');

/**
 * Obtiene el carrito completo del usuario con datos del producto.
 */
const obtenerCarrito = async (usuarioId) => {
  const [rows] = await db.query(
    `SELECT c.id, c.cantidad, c.agregado_en,
            p.id AS producto_id, p.nombre, p.precio, p.imagen_url, p.stock
     FROM carrito c
     JOIN productos p ON c.producto_id = p.id
     WHERE c.usuario_id = ?
     ORDER BY c.agregado_en DESC`,
    [usuarioId]
  );

  const subtotal = rows.reduce((sum, item) => sum + item.precio * item.cantidad, 0);
  return { items: rows, subtotal: parseFloat(subtotal.toFixed(2)) };
};

/**
 * Añade un producto al carrito o incrementa su cantidad.
 */
const agregarAlCarrito = async (usuarioId, productoId, cantidad = 1) => {
  // Verificar que el producto exista y tenga stock
  const [productos] = await db.query(
    'SELECT id, stock FROM productos WHERE id = ? AND activo = TRUE', [productoId]
  );
  if (productos.length === 0) throw { status: 404, message: 'Producto no encontrado' };
  if (productos[0].stock < cantidad) throw { status: 400, message: 'Stock insuficiente' };

  // Insertar o actualizar (ON DUPLICATE KEY UPDATE)
  await db.query(
    `INSERT INTO carrito (usuario_id, producto_id, cantidad)
     VALUES (?, ?, ?)
     ON DUPLICATE KEY UPDATE cantidad = cantidad + VALUES(cantidad)`,
    [usuarioId, productoId, cantidad]
  );

  return obtenerCarrito(usuarioId);
};

/**
 * Actualiza la cantidad de un item del carrito.
 */
const actualizarCantidad = async (carritoItemId, usuarioId, cantidad) => {
  if (cantidad <= 0) {
    return eliminarDelCarrito(carritoItemId, usuarioId);
  }

  const [result] = await db.query(
    'UPDATE carrito SET cantidad = ? WHERE id = ? AND usuario_id = ?',
    [cantidad, carritoItemId, usuarioId]
  );
  if (result.affectedRows === 0) throw { status: 404, message: 'Item no encontrado en el carrito' };

  return obtenerCarrito(usuarioId);
};

/**
 * Elimina un item del carrito.
 */
const eliminarDelCarrito = async (carritoItemId, usuarioId) => {
  const [result] = await db.query(
    'DELETE FROM carrito WHERE id = ? AND usuario_id = ?',
    [carritoItemId, usuarioId]
  );
  if (result.affectedRows === 0) throw { status: 404, message: 'Item no encontrado en el carrito' };
  return obtenerCarrito(usuarioId);
};

/**
 * Vacía completamente el carrito del usuario.
 */
const vaciarCarrito = async (usuarioId) => {
  await db.query('DELETE FROM carrito WHERE usuario_id = ?', [usuarioId]);
  return { items: [], subtotal: 0 };
};

module.exports = { obtenerCarrito, agregarAlCarrito, actualizarCantidad, eliminarDelCarrito, vaciarCarrito };
