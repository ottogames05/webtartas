// src/services/productos.service.js
// Lógica de negocio para gestión de productos
const db = require('../config/db');

/**
 * Obtiene todos los productos con filtros opcionales.
 * @param {object} filtros - { categoria, busqueda, minPrecio, maxPrecio, destacado, pagina, limite }
 */
const listarProductos = async (filtros = {}) => {
  const { categoria, busqueda, minPrecio, maxPrecio, destacado, pagina = 1, limite = 12 } = filtros;
  const offset = (pagina - 1) * limite;
  const params = [];
  const conds  = ['p.activo = TRUE'];

  if (categoria)  { conds.push('c.id = ?');            params.push(categoria); }
  if (busqueda)   { conds.push('p.nombre LIKE ?');      params.push(`%${busqueda}%`); }
  if (minPrecio)  { conds.push('p.precio >= ?');        params.push(minPrecio); }
  if (maxPrecio)  { conds.push('p.precio <= ?');        params.push(maxPrecio); }
  if (destacado)  { conds.push('p.destacado = TRUE'); }

  const where = conds.length ? `WHERE ${conds.join(' AND ')}` : '';

  const sql = `
    SELECT p.*, c.nombre AS categoria_nombre
    FROM productos p
    LEFT JOIN categorias c ON p.categoria_id = c.id
    ${where}
    ORDER BY p.destacado DESC, p.creado_en DESC
    LIMIT ? OFFSET ?
  `;
  params.push(parseInt(limite), parseInt(offset));

  const [rows] = await db.query(sql, params);

  // Total para paginación
  const countSql = `
    SELECT COUNT(*) AS total
    FROM productos p
    LEFT JOIN categorias c ON p.categoria_id = c.id
    ${where}
  `;
  const [countRows] = await db.query(countSql, params.slice(0, -2));
  const total = countRows[0].total;

  return { productos: rows, total, pagina: parseInt(pagina), limite: parseInt(limite) };
};

/**
 * Obtiene un producto por su ID.
 */
const obtenerProducto = async (id) => {
  const [rows] = await db.query(
    `SELECT p.*, c.nombre AS categoria_nombre
     FROM productos p
     LEFT JOIN categorias c ON p.categoria_id = c.id
     WHERE p.id = ? AND p.activo = TRUE`,
    [id]
  );
  if (rows.length === 0) throw { status: 404, message: 'Producto no encontrado' };
  return rows[0];
};

/**
 * Crea un nuevo producto.
 */
const crearProducto = async (datos) => {
  const { nombre, descripcion, precio, imagen_url, stock, categoria_id, destacado } = datos;
  const [result] = await db.query(
    `INSERT INTO productos (nombre, descripcion, precio, imagen_url, stock, categoria_id, destacado)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [nombre, descripcion, precio, imagen_url || '/images/default-cake.jpg', stock, categoria_id, destacado || false]
  );
  return obtenerProducto(result.insertId);
};

/**
 * Actualiza un producto existente.
 */
const actualizarProducto = async (id, datos) => {
  const { nombre, descripcion, precio, imagen_url, stock, categoria_id, activo, destacado } = datos;
  const [result] = await db.query(
    `UPDATE productos
     SET nombre = ?, descripcion = ?, precio = ?, imagen_url = ?,
         stock = ?, categoria_id = ?, activo = ?, destacado = ?
     WHERE id = ?`,
    [nombre, descripcion, precio, imagen_url, stock, categoria_id, activo ?? true, destacado ?? false, id]
  );
  if (result.affectedRows === 0) throw { status: 404, message: 'Producto no encontrado' };
  return obtenerProducto(id);
};

/**
 * Elimina (desactiva) un producto.
 */
const eliminarProducto = async (id) => {
  const [result] = await db.query(
    'UPDATE productos SET activo = FALSE WHERE id = ?', [id]
  );
  if (result.affectedRows === 0) throw { status: 404, message: 'Producto no encontrado' };
  return { mensaje: 'Producto eliminado correctamente' };
};

/**
 * Actualiza solo la imagen de un producto.
 */
const actualizarImagen = async (id, imagenUrl) => {
  await db.query('UPDATE productos SET imagen_url = ? WHERE id = ?', [imagenUrl, id]);
  return obtenerProducto(id);
};

/**
 * Lista todas las categorías.
 */
const listarCategorias = async () => {
  const [rows] = await db.query('SELECT * FROM categorias ORDER BY nombre');
  return rows;
};

module.exports = {
  listarProductos, obtenerProducto, crearProducto,
  actualizarProducto, eliminarProducto, actualizarImagen, listarCategorias,
};
