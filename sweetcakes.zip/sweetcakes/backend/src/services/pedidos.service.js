// src/services/pedidos.service.js
// Lógica de negocio para los pedidos
const db = require('../config/db');

/**
 * Crea un pedido a partir del carrito actual del usuario.
 * Usa transacción para garantizar consistencia.
 */
const crearPedido = async (usuarioId, { direccion_envio, notas, metodo_pago }) => {
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();

    // Obtener items del carrito con precios actuales
    const [items] = await conn.query(
      `SELECT c.producto_id, c.cantidad, p.precio, p.nombre, p.stock
       FROM carrito c
       JOIN productos p ON c.producto_id = p.id
       WHERE c.usuario_id = ?`,
      [usuarioId]
    );

    if (items.length === 0) throw { status: 400, message: 'El carrito está vacío' };

    // Verificar stock y calcular total
    for (const item of items) {
      if (item.stock < item.cantidad) {
        throw { status: 400, message: `Stock insuficiente para "${item.nombre}"` };
      }
    }
    const total = items.reduce((sum, i) => sum + i.precio * i.cantidad, 0);

    // Crear pedido
    const [pedidoResult] = await conn.query(
      `INSERT INTO pedidos (usuario_id, total, direccion_envio, notas, metodo_pago)
       VALUES (?, ?, ?, ?, ?)`,
      [usuarioId, total.toFixed(2), direccion_envio, notas, metodo_pago || 'tarjeta']
    );
    const pedidoId = pedidoResult.insertId;

    // Insertar detalles y reducir stock
    for (const item of items) {
      await conn.query(
        `INSERT INTO detalle_pedidos (pedido_id, producto_id, nombre_producto, cantidad, precio_unitario)
         VALUES (?, ?, ?, ?, ?)`,
        [pedidoId, item.producto_id, item.nombre, item.cantidad, item.precio]
      );
      await conn.query(
        'UPDATE productos SET stock = stock - ? WHERE id = ?',
        [item.cantidad, item.producto_id]
      );
    }

    // Vaciar carrito
    await conn.query('DELETE FROM carrito WHERE usuario_id = ?', [usuarioId]);

    await conn.commit();
    return obtenerPedido(pedidoId, usuarioId);
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
};

/**
 * Obtiene un pedido con sus detalles. Verifica propiedad del usuario
 * a menos que se omita usuarioId (para admin).
 */
const obtenerPedido = async (pedidoId, usuarioId = null) => {
  const cond = usuarioId ? 'AND p.usuario_id = ?' : '';
  const params = usuarioId ? [pedidoId, usuarioId] : [pedidoId];

  const [pedidos] = await db.query(
    `SELECT p.*, u.nombre AS cliente_nombre, u.email AS cliente_email
     FROM pedidos p
     JOIN usuarios u ON p.usuario_id = u.id
     WHERE p.id = ? ${cond}`,
    params
  );
  if (pedidos.length === 0) throw { status: 404, message: 'Pedido no encontrado' };

  const [detalles] = await db.query(
    `SELECT dp.*, pr.imagen_url
     FROM detalle_pedidos dp
     LEFT JOIN productos pr ON dp.producto_id = pr.id
     WHERE dp.pedido_id = ?`,
    [pedidoId]
  );

  return { ...pedidos[0], detalles };
};

/**
 * Lista los pedidos de un usuario.
 */
const listarPedidosUsuario = async (usuarioId) => {
  const [rows] = await db.query(
    `SELECT p.id, p.fecha, p.total, p.estado, p.metodo_pago,
            COUNT(dp.id) AS num_productos
     FROM pedidos p
     LEFT JOIN detalle_pedidos dp ON p.id = dp.pedido_id
     WHERE p.usuario_id = ?
     GROUP BY p.id
     ORDER BY p.fecha DESC`,
    [usuarioId]
  );
  return rows;
};

/**
 * Lista TODOS los pedidos (admin).
 */
const listarTodosPedidos = async (estado = null) => {
  const cond = estado ? 'WHERE p.estado = ?' : '';
  const [rows] = await db.query(
    `SELECT p.id, p.fecha, p.total, p.estado, p.metodo_pago,
            u.nombre AS cliente_nombre, u.email AS cliente_email,
            COUNT(dp.id) AS num_productos
     FROM pedidos p
     JOIN usuarios u ON p.usuario_id = u.id
     LEFT JOIN detalle_pedidos dp ON p.id = dp.pedido_id
     ${cond}
     GROUP BY p.id
     ORDER BY p.fecha DESC`,
    estado ? [estado] : []
  );
  return rows;
};

/**
 * Cambia el estado de un pedido (admin).
 */
const cambiarEstadoPedido = async (pedidoId, nuevoEstado) => {
  const estadosValidos = ['pendiente', 'procesando', 'enviado', 'entregado', 'cancelado'];
  if (!estadosValidos.includes(nuevoEstado)) {
    throw { status: 400, message: 'Estado inválido' };
  }
  const [result] = await db.query(
    'UPDATE pedidos SET estado = ? WHERE id = ?', [nuevoEstado, pedidoId]
  );
  if (result.affectedRows === 0) throw { status: 404, message: 'Pedido no encontrado' };
  return obtenerPedido(pedidoId);
};

module.exports = { crearPedido, obtenerPedido, listarPedidosUsuario, listarTodosPedidos, cambiarEstadoPedido };
