// src/routes/auth.routes.js
const router     = require('express').Router();
const { body }   = require('express-validator');
const ctrl       = require('../controllers/auth.controller');
const { verificarToken } = require('../middleware/auth');

// POST /api/auth/registro
router.post('/registro', [
  body('nombre').trim().notEmpty().withMessage('El nombre es requerido'),
  body('email').isEmail().withMessage('Email inválido').normalizeEmail(),
  body('password').isLength({ min: 6 }).withMessage('La contraseña debe tener al menos 6 caracteres'),
], ctrl.registro);

// POST /api/auth/login
router.post('/login', [
  body('email').isEmail().withMessage('Email inválido').normalizeEmail(),
  body('password').notEmpty().withMessage('La contraseña es requerida'),
], ctrl.login);

// GET /api/auth/perfil  (requiere token)
router.get('/perfil', verificarToken, ctrl.perfil);

// PUT /api/auth/perfil  (requiere token)
router.put('/perfil', verificarToken, ctrl.actualizarPerfil);

module.exports = router;
