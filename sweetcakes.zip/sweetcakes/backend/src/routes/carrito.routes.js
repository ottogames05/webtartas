// src/routes/carrito.routes.js
const router = require('express').Router();
const ctrl   = require('../controllers/carrito.controller');
const { verificarToken } = require('../middleware/auth');

// Todas las rutas del carrito requieren autenticación
router.use(verificarToken);

router.get('/',        ctrl.obtener);   // GET  /api/carrito
router.post('/',       ctrl.agregar);   // POST /api/carrito
router.put('/:id',     ctrl.actualizar);// PUT  /api/carrito/:id
router.delete('/',     ctrl.vaciar);    // DELETE /api/carrito (vaciar todo)
router.delete('/:id',  ctrl.eliminar);  // DELETE /api/carrito/:id

module.exports = router;
