// src/routes/productos.routes.js
const router = require('express').Router();
const ctrl   = require('../controllers/productos.controller');
const { verificarToken } = require('../middleware/auth');
const { soloAdmin }      = require('../middleware/admin');
const upload             = require('../middleware/upload');

// GET /api/productos  — público, con filtros via query params
router.get('/',        ctrl.listar);

// GET /api/categorias — público
router.get('/categorias', ctrl.categorias);

// GET /api/productos/:id — público
router.get('/:id',     ctrl.obtener);

// POST /api/productos — solo admin, con upload de imagen opcional
router.post('/', verificarToken, soloAdmin, upload.single('imagen'), ctrl.crear);

// PUT /api/productos/:id — solo admin
router.put('/:id', verificarToken, soloAdmin, upload.single('imagen'), ctrl.actualizar);

// DELETE /api/productos/:id — solo admin
router.delete('/:id', verificarToken, soloAdmin, ctrl.eliminar);

// POST /api/productos/:id/imagen — solo admin
router.post('/:id/imagen', verificarToken, soloAdmin, upload.single('imagen'), ctrl.subirImagen);

module.exports = router;
