// src/routes/admin.routes.js
const router = require('express').Router();
const ctrl   = require('../controllers/admin.controller');
const pedidosCtrl = require('../controllers/pedidos.controller');
const { verificarToken } = require('../middleware/auth');
const { soloAdmin }      = require('../middleware/admin');

// Todas las rutas admin requieren token + rol admin
router.use(verificarToken, soloAdmin);

router.get('/estadisticas',       ctrl.estadisticas);          // GET /api/admin/estadisticas
router.get('/usuarios',           ctrl.listarUsuarios);        // GET /api/admin/usuarios
router.put('/usuarios/:id/rol',   ctrl.cambiarRol);            // PUT /api/admin/usuarios/:id/rol
router.get('/pedidos',            pedidosCtrl.todosLosPedidos);// GET /api/admin/pedidos
router.get('/pedidos/:id',        pedidosCtrl.detalleAdmin);   // GET /api/admin/pedidos/:id
router.put('/pedidos/:id/estado', pedidosCtrl.cambiarEstado);  // PUT /api/admin/pedidos/:id/estado

module.exports = router;
