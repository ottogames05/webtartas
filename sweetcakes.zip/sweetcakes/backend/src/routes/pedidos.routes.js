// src/routes/pedidos.routes.js
const router = require('express').Router();
const ctrl   = require('../controllers/pedidos.controller');
const { verificarToken } = require('../middleware/auth');
const { soloAdmin }      = require('../middleware/admin');

router.use(verificarToken);

// Rutas de usuario
router.post('/',     ctrl.crear);       // POST /api/pedidos
router.get('/mis',   ctrl.misPedidos);  // GET  /api/pedidos/mis
router.get('/:id',   ctrl.detalle);     // GET  /api/pedidos/:id

// Rutas de admin
router.get('/',            soloAdmin, ctrl.todosLosPedidos);         // GET  /api/pedidos
router.get('/admin/:id',   soloAdmin, ctrl.detalleAdmin);            // GET  /api/pedidos/admin/:id
router.put('/:id/estado',  soloAdmin, ctrl.cambiarEstado);           // PUT  /api/pedidos/:id/estado

module.exports = router;
