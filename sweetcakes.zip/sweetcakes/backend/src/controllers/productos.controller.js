// src/controllers/productos.controller.js
const productosService = require('../services/productos.service');

const listar = async (req, res) => {
  try {
    const resultado = await productosService.listarProductos(req.query);
    res.json(resultado);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

const obtener = async (req, res) => {
  try {
    const producto = await productosService.obtenerProducto(req.params.id);
    res.json(producto);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

const crear = async (req, res) => {
  try {
    const datos = { ...req.body };
    if (req.file) datos.imagen_url = `/uploads/${req.file.filename}`;
    const producto = await productosService.crearProducto(datos);
    res.status(201).json({ mensaje: 'Producto creado', producto });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

const actualizar = async (req, res) => {
  try {
    const datos = { ...req.body };
    if (req.file) datos.imagen_url = `/uploads/${req.file.filename}`;
    const producto = await productosService.actualizarProducto(req.params.id, datos);
    res.json({ mensaje: 'Producto actualizado', producto });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

const eliminar = async (req, res) => {
  try {
    const resultado = await productosService.eliminarProducto(req.params.id);
    res.json(resultado);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

const subirImagen = async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No se subió ninguna imagen' });
    const imagenUrl = `/uploads/${req.file.filename}`;
    const producto  = await productosService.actualizarImagen(req.params.id, imagenUrl);
    res.json({ mensaje: 'Imagen actualizada', imagenUrl, producto });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

const categorias = async (_req, res) => {
  try {
    const lista = await productosService.listarCategorias();
    res.json(lista);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = { listar, obtener, crear, actualizar, eliminar, subirImagen, categorias };
