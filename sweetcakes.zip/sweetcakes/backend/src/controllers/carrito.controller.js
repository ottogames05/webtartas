// src/controllers/carrito.controller.js
const carritoService = require('../services/carrito.service');

const obtener = async (req, res) => {
  try {
    const carrito = await carritoService.obtenerCarrito(req.usuario.id);
    res.json(carrito);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

const agregar = async (req, res) => {
  try {
    const { producto_id, cantidad } = req.body;
    if (!producto_id) return res.status(400).json({ error: 'producto_id es requerido' });
    const carrito = await carritoService.agregarAlCarrito(req.usuario.id, producto_id, cantidad || 1);
    res.json({ mensaje: 'Producto añadido al carrito', carrito });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

const actualizar = async (req, res) => {
  try {
    const { cantidad } = req.body;
    if (cantidad === undefined) return res.status(400).json({ error: 'cantidad es requerida' });
    const carrito = await carritoService.actualizarCantidad(req.params.id, req.usuario.id, cantidad);
    res.json({ mensaje: 'Carrito actualizado', carrito });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

const eliminar = async (req, res) => {
  try {
    const carrito = await carritoService.eliminarDelCarrito(req.params.id, req.usuario.id);
    res.json({ mensaje: 'Producto eliminado del carrito', carrito });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

const vaciar = async (req, res) => {
  try {
    const carrito = await carritoService.vaciarCarrito(req.usuario.id);
    res.json({ mensaje: 'Carrito vaciado', carrito });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

module.exports = { obtener, agregar, actualizar, eliminar, vaciar };
