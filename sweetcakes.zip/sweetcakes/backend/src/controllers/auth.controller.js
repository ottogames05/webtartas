// src/controllers/auth.controller.js
const { validationResult } = require('express-validator');
const authService = require('../services/auth.service');

const registro = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errores: errors.array() });

  try {
    const { nombre, email, password } = req.body;
    const usuario = await authService.registrarUsuario(nombre, email, password);
    res.status(201).json({ mensaje: 'Usuario registrado correctamente', usuario });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message || 'Error interno del servidor' });
  }
};

const login = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errores: errors.array() });

  try {
    const { email, password } = req.body;
    const resultado = await authService.loginUsuario(email, password);
    res.json(resultado);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message || 'Error interno del servidor' });
  }
};

const perfil = async (req, res) => {
  try {
    const usuario = await authService.obtenerPerfil(req.usuario.id);
    res.json(usuario);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

const actualizarPerfil = async (req, res) => {
  try {
    const usuario = await authService.actualizarPerfil(req.usuario.id, req.body);
    res.json({ mensaje: 'Perfil actualizado', usuario });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

module.exports = { registro, login, perfil, actualizarPerfil };
