// src/controllers/pedidos.controller.js
const pedidosService = require('../services/pedidos.service');

const crear = async (req, res) => {
  try {
    const pedido = await pedidosService.crearPedido(req.usuario.id, req.body);
    res.status(201).json({ mensaje: 'Pedido creado correctamente', pedido });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

const misPedidos = async (req, res) => {
  try {
    const pedidos = await pedidosService.listarPedidosUsuario(req.usuario.id);
    res.json(pedidos);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

const detalle = async (req, res) => {
  try {
    const pedido = await pedidosService.obtenerPedido(req.params.id, req.usuario.id);
    res.json(pedido);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

// Admin
const todosLosPedidos = async (req, res) => {
  try {
    const pedidos = await pedidosService.listarTodosPedidos(req.query.estado);
    res.json(pedidos);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

const cambiarEstado = async (req, res) => {
  try {
    const { estado } = req.body;
    if (!estado) return res.status(400).json({ error: 'estado es requerido' });
    const pedido = await pedidosService.cambiarEstadoPedido(req.params.id, estado);
    res.json({ mensaje: 'Estado actualizado', pedido });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

const detalleAdmin = async (req, res) => {
  try {
    const pedido = await pedidosService.obtenerPedido(req.params.id);
    res.json(pedido);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

module.exports = { crear, misPedidos, detalle, todosLosPedidos, cambiarEstado, detalleAdmin };
