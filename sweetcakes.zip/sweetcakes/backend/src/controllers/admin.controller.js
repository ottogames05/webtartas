// src/controllers/admin.controller.js
// Dashboard y gestión de usuarios para el panel admin
const db = require('../config/db');

/**
 * Estadísticas generales para el dashboard.
 */
const estadisticas = async (_req, res) => {
  try {
    // Total de ventas (pedidos no cancelados)
    const [[{ total_ventas }]] = await db.query(
      `SELECT COALESCE(SUM(total), 0) AS total_ventas
       FROM pedidos WHERE estado != 'cancelado'`
    );
    // Número de pedidos
    const [[{ num_pedidos }]] = await db.query(
      'SELECT COUNT(*) AS num_pedidos FROM pedidos'
    );
    // Número de usuarios
    const [[{ num_usuarios }]] = await db.query(
      `SELECT COUNT(*) AS num_usuarios FROM usuarios WHERE rol = 'usuario'`
    );
    // Número de productos activos
    const [[{ num_productos }]] = await db.query(
      'SELECT COUNT(*) AS num_productos FROM productos WHERE activo = TRUE'
    );
    // Pedidos por estado
    const [estadosPedidos] = await db.query(
      `SELECT estado, COUNT(*) AS total FROM pedidos GROUP BY estado`
    );
    // Ventas últimos 7 días
    const [ventasSemana] = await db.query(
      `SELECT DATE(fecha) AS dia, SUM(total) AS ventas
       FROM pedidos
       WHERE fecha >= DATE_SUB(NOW(), INTERVAL 7 DAY) AND estado != 'cancelado'
       GROUP BY DATE(fecha)
       ORDER BY dia ASC`
    );
    // Top 5 productos más vendidos
    const [topProductos] = await db.query(
      `SELECT pr.nombre, SUM(dp.cantidad) AS vendidos, SUM(dp.subtotal) AS ingresos
       FROM detalle_pedidos dp
       JOIN productos pr ON dp.producto_id = pr.id
       JOIN pedidos pe ON dp.pedido_id = pe.id
       WHERE pe.estado != 'cancelado'
       GROUP BY pr.id
       ORDER BY vendidos DESC
       LIMIT 5`
    );

    res.json({ total_ventas, num_pedidos, num_usuarios, num_productos,
               estadosPedidos, ventasSemana, topProductos });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

/**
 * Lista todos los usuarios (admin).
 */
const listarUsuarios = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT u.id, u.nombre, u.email, u.rol, u.telefono, u.creado_en,
              COUNT(p.id) AS num_pedidos
       FROM usuarios u
       LEFT JOIN pedidos p ON u.id = p.usuario_id
       GROUP BY u.id
       ORDER BY u.creado_en DESC`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

/**
 * Cambia el rol de un usuario.
 */
const cambiarRol = async (req, res) => {
  try {
    const { rol } = req.body;
    if (!['usuario', 'admin'].includes(rol)) {
      return res.status(400).json({ error: 'Rol inválido' });
    }
    await db.query('UPDATE usuarios SET rol = ? WHERE id = ?', [rol, req.params.id]);
    res.json({ mensaje: 'Rol actualizado correctamente' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = { estadisticas, listarUsuarios, cambiarRol };
