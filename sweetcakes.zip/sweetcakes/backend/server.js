// server.js — Punto de entrada del servidor SweetCakes API
require('dotenv').config();
const app  = require('./src/app');

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log('');
  console.log('🎂 ================================');
  console.log(`🎂  SweetCakes API arrancado`);
  console.log(`🎂  Puerto : ${PORT}`);
  console.log(`🎂  Entorno: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🎂  URL    : http://localhost:${PORT}/api`);
  console.log('🎂 ================================');
  console.log('');
});
